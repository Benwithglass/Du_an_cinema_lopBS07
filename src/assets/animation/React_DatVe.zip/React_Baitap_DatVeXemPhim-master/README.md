Ghi chú về dự án Movie

Các thư mục cần tạo: 
    - Components 
    - pages
    - redux 
    - services : nơi lưu trữ các phương thức về gọi dữ liệu 
    - utilities: nơi chứa các hàm, các logic hỗ trợ
    - assets: nơi lưu trữ các hình ảnh, mp4, json, svg,... 
    - templates

Các thư viện cần cài đặt:
    - react-router-dom 
    - axios
    - redux  - react-redux
    - ant design 
    - tailwind css
    - sass - sass-loader