import {combineReducers} from 'redux'

import BaitapDatVeReducer from './BaitapDatVeReducer';

const rootReducer = combineReducers ({
    BaitapDatVeReducer,
})

export default rootReducer;